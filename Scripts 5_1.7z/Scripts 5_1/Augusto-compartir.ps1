net share lunes>resultado-augusto.txt
net share martes>resultado-augusto.txt
net share Sabado>>resultado-augusto.txt
net share Domingo>>resultado-augusto.txt
net share Documentos>resultado-augusto.txt
net share Imagenes>resultado-augusto.txt
net share Videos>>resultado-augusto.txt
net share Audios>>resultado-augusto.txt
net share Trabajos>>resultado-augusto.txt



net share Lunes=C:\clase
net share Martes=C:\clase
net share Sabado=C:\clase
net share Domingo=C:\clase
net share Documentos=C:\datos
net share Videos=C:\Datos
net share Audios=C:\Datos
net share Trabajos=C:\Datos




net share Trabajos=C:\trabajos

